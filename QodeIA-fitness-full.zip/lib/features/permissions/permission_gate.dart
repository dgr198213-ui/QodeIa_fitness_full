import 'package:flutter/material.dart';
import '../../services/permissions/permission_service.dart';
import '../home/home_screen.dart';

class PermissionGate extends StatefulWidget {
  const PermissionGate({super.key});

  @override
  State<PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<PermissionGate> {
  bool granted = false;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final ok = await PermissionService.hasAll();
    setState(() {
      granted = ok;
      loading = false;
    });
  }

  Future<void> _request() async {
    setState(() => loading = true);
    final ok = await PermissionService.requestAll();
    setState(() {
      granted = ok;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (granted) return const HomeScreen();

    return Scaffold(
      body: Center(
        child: FilledButton(
          onPressed: _request,
          child: const Text("Conceder permisos"),
        ),
      ),
    );
  }
}
