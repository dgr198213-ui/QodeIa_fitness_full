import 'package:flutter/material.dart';
import '../../services/agtr15/agtr15_engine.dart';
import '../../services/voice/voice_service.dart';
import '../../services/ble/ble_heart_rate_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final engine = Agtr15Engine();
  final voice = VoiceService();
  final ble = BleHeartRateService();

  double intensity = 0;
  int? hr;

  @override
  void initState() {
    super.initState();
    voice.init();
    ble.hr$.listen((bpm) {
      setState(() {
        hr = bpm;
        intensity = engine.compute(hr: hr, acc: 5);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("QodeIA Fitness")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("HR: ${hr ?? '--'}"),
            Text("Intensidad: ${intensity.toStringAsFixed(0)}"),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () async {
                await voice.speak("Entrenamiento iniciado");
                await ble.startScanAndConnect();
              },
              child: const Text("Iniciar sesión"),
            ),
          ],
        ),
      ),
    );
  }
}
