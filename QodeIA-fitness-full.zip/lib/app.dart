import 'package:flutter/material.dart';
import 'features/permissions/permission_gate.dart';

class QodeIAApp extends StatelessWidget {
  const QodeIAApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'QodeIA Fitness',
      theme: ThemeData.dark(useMaterial3: true),
      home: const PermissionGate(),
    );
  }
}
