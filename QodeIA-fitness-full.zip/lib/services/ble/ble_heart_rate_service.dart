import 'dart:async';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class BleHeartRateService {
  static final Guid hrService =
      Guid("0000180d-0000-1000-8000-00805f9b34fb");
  static final Guid hrChar =
      Guid("00002a37-0000-1000-8000-00805f9b34fb");

  final _hrCtrl = StreamController<int>.broadcast();
  Stream<int> get hr$ => _hrCtrl.stream;

  Future<void> startScanAndConnect() async {
    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 5));
    final results = await FlutterBluePlus.scanResults.first;
    await FlutterBluePlus.stopScan();

    if (results.isEmpty) return;
    final device = results.first.device;
    await device.connect();

    final services = await device.discoverServices();
    final service = services.firstWhere((s) => s.uuid == hrService);
    final characteristic =
        service.characteristics.firstWhere((c) => c.uuid == hrChar);

    await characteristic.setNotifyValue(true);
    characteristic.onValueReceived.listen((data) {
      if (data.length > 1) _hrCtrl.add(data[1]);
    });
  }
}
