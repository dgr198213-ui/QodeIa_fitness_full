import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  static Future<bool> requestAll() async {
    final permissions = [
      Permission.microphone,
      Permission.locationWhenInUse,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ];
    final result = await permissions.request();
    return result.values.every((p) => p.isGranted);
  }

  static Future<bool> hasAll() async {
    return await Permission.microphone.isGranted &&
        await Permission.locationWhenInUse.isGranted &&
        await Permission.bluetoothScan.isGranted &&
        await Permission.bluetoothConnect.isGranted;
  }
}
