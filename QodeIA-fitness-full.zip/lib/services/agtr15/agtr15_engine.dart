class Agtr15Engine {
  double compute({int? hr, double acc = 0, bool rest = false}) {
    double score = 0;
    if (hr != null) score += hr / 190;
    score += acc / 20;
    if (rest) score *= 0.5;
    return (score * 100).clamp(0, 100);
  }
}
