# QodeIA Fitness

Entrenador inteligente en Flutter con:

- Bluetooth HR (0x180D)
- Voz TTS en español
- Motor AGTR15 en tiempo real
- Gestión de permisos Android

## Ejecutar
flutter pub get
flutter run
